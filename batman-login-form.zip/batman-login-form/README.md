# Batman login form

A Pen created on CodePen.io. Original URL: [https://codepen.io/KittyGiraudel/pen/DwvByr](https://codepen.io/KittyGiraudel/pen/DwvByr).

Inspired by Virgil Pana's work on Dribbble : http://dribbble.com/shots/656020-Login. The whole point was to make the shiny light effet on the top of the box.