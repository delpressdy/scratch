<?php 
	$con=mysqli_connect("localhost","root","","invoice_db");
?>